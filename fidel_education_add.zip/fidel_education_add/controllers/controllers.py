# -*- coding: utf-8 -*-
# from odoo import http


# class FidelEducationAdd(http.Controller):
#     @http.route('/fidel_education_add/fidel_education_add/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/fidel_education_add/fidel_education_add/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('fidel_education_add.listing', {
#             'root': '/fidel_education_add/fidel_education_add',
#             'objects': http.request.env['fidel_education_add.fidel_education_add'].search([]),
#         })

#     @http.route('/fidel_education_add/fidel_education_add/objects/<model("fidel_education_add.fidel_education_add"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('fidel_education_add.object', {
#             'object': obj
#         })
